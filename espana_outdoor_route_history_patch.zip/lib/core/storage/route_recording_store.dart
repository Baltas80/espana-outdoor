import 'package:hive_ce_flutter/hive_ce_flutter.dart';

import '../domain/outdoor_models.dart';

final class RouteRecordingSession {
  const RouteRecordingSession({
    required this.startedAt,
    required this.points,
    required this.distanceMeters,
    this.id = 'active',
    this.completedAt,
  });

  final String id;
  final DateTime startedAt;
  final List<GeoPoint> points;
  final double distanceMeters;
  final DateTime? completedAt;
}

final class RouteRecordingStore {
  RouteRecordingStore({Box<dynamic>? box})
      : _box = box ?? Hive.box<dynamic>(_boxName);

  static const _boxName = 'route_tracking';
  static const _metadataKey = '__active_session__';
  static const _segmentPrefix = '__segment__';
  static const _routeMetadataPrefix = '__route__';
  static const _routeSegmentPrefix = '__route_segment__';
  static const _segmentSize = 50;

  final Box<dynamic> _box;

  /// Starts a new active session without deleting previously completed routes.
  Future<void> begin({required DateTime startedAt}) async {
    await clear();
    await _box.put(_metadataKey, <String, Object?>{
      'active': true,
      'startedAt': startedAt.toUtc().toIso8601String(),
      'distanceMeters': 0.0,
      'segmentCount': 1,
      'pointCount': 0,
    });
    await _box.put(_segmentKey(0), <Object?>[]);
  }

  Future<void> append({
    required GeoPoint point,
    required double distanceMeters,
  }) async {
    final metadata = _metadata;
    if (metadata == null || metadata['active'] != true) {
      throw StateError('No active route recording session.');
    }

    var segmentCount = (metadata['segmentCount'] as num?)?.toInt() ?? 1;
    if (segmentCount <= 0) segmentCount = 1;

    var segmentIndex = segmentCount - 1;
    var key = _segmentKey(segmentIndex);
    final raw = _box.get(key);
    final segment = raw is List ? List<Object?>.from(raw) : <Object?>[];

    if (segment.length >= _segmentSize) {
      segmentIndex += 1;
      segment.clear();
      segmentCount = segmentIndex + 1;
      key = _segmentKey(segmentIndex);
    }

    segment.add(<String, Object?>{
      'latitude': point.latitude,
      'longitude': point.longitude,
    });
    await _box.put(key, segment);

    await _box.put(_metadataKey, <String, Object?>{
      ...metadata,
      'distanceMeters': distanceMeters,
      'segmentCount': segmentCount,
      'pointCount': ((metadata['pointCount'] as num?)?.toInt() ?? 0) + 1,
    });
  }

  /// Returns the active/interrupted session, if one exists.
  RouteRecordingSession? recover() {
    final metadata = _metadata;
    if (metadata == null || metadata['active'] != true) return null;
    return _readSession(
      metadata: metadata,
      id: 'active',
      segmentKey: _segmentKey,
    );
  }

  /// Lists completed routes, newest first.
  List<RouteRecordingSession> getRoutes() {
    final routes = <RouteRecordingSession>[];
    for (final key in _box.keys) {
      final keyText = key.toString();
      if (!keyText.startsWith(_routeMetadataPrefix)) continue;
      final value = _box.get(key);
      if (value is! Map || value['active'] == true) continue;
      final id = keyText.substring(_routeMetadataPrefix.length);
      final session = _readSession(
        metadata: value,
        id: id,
        segmentKey: (index) => _routeSegmentKey(id, index),
      );
      if (session != null) routes.add(session);
    }
    routes.sort((a, b) => b.startedAt.compareTo(a.startedAt));
    return List.unmodifiable(routes);
  }

  /// Loads one completed route by its stable route ID.
  RouteRecordingSession? loadRoute(String routeId) {
    final metadata = _box.get('$_routeMetadataPrefix$routeId');
    if (metadata is! Map || metadata['active'] == true) return null;
    return _readSession(
      metadata: metadata,
      id: routeId,
      segmentKey: (index) => _routeSegmentKey(routeId, index),
    );
  }

  bool get hasActiveSession => _metadata?['active'] == true;

  /// Archives the active route before removing its active-session keys.
  Future<void> finish() async {
    final metadata = _metadata;
    if (metadata == null || metadata['active'] != true) return;

    final startedAt = DateTime.tryParse(metadata['startedAt']?.toString() ?? '');
    if (startedAt == null) {
      throw StateError('Cannot archive route: invalid start timestamp.');
    }

    final segmentCount = (metadata['segmentCount'] as num?)?.toInt() ?? 0;
    if (segmentCount <= 0) {
      throw StateError('Cannot archive route: invalid segment count.');
    }

    final baseId = startedAt.toUtc().microsecondsSinceEpoch.toString();
    var routeId = baseId;
    var suffix = 1;
    while (_box.containsKey('$_routeMetadataPrefix$routeId')) {
      routeId = '${baseId}_$suffix';
      suffix++;
    }

    for (var index = 0; index < segmentCount; index++) {
      final raw = _box.get(_segmentKey(index));
      await _box.put(
        _routeSegmentKey(routeId, index),
        raw is List ? List<Object?>.from(raw) : <Object?>[],
      );
    }

    final completedAt = DateTime.now().toUtc();
    await _box.put('$_routeMetadataPrefix$routeId', <String, Object?>{
      ...metadata,
      'active': false,
      'routeId': routeId,
      'completedAt': completedAt.toIso8601String(),
      'segmentCount': segmentCount,
    });

    await clear();
  }

  /// Clears only the active/interrupted session. Completed routes are retained.
  Future<void> clear() async {
    final keys = _box.keys
        .where((key) {
          final text = key.toString();
          return text == _metadataKey || text.startsWith(_segmentPrefix);
        })
        .toList(growable: false);

    for (final key in keys) {
      await _box.delete(key);
    }
  }

  /// Explicit operation for a future user-confirmed delete-history feature.
  Future<void> clearHistory() async {
    final keys = _box.keys
        .where((key) {
          final text = key.toString();
          return text.startsWith(_routeMetadataPrefix) ||
              text.startsWith(_routeSegmentPrefix);
        })
        .toList(growable: false);
    for (final key in keys) {
      await _box.delete(key);
    }
  }

  RouteRecordingSession? _readSession({
    required Map<dynamic, dynamic> metadata,
    required String id,
    required String Function(int index) segmentKey,
  }) {
    final startedAt = DateTime.tryParse(metadata['startedAt']?.toString() ?? '');
    if (startedAt == null) return null;

    final segmentCount = (metadata['segmentCount'] as num?)?.toInt() ?? 0;
    if (segmentCount <= 0) return null;

    final points = <GeoPoint>[];
    for (var index = 0; index < segmentCount; index++) {
      final raw = _box.get(segmentKey(index));
      if (raw is! List) continue;
      for (final item in raw) {
        if (item is! Map) continue;
        final latitude = _asDouble(item['latitude']);
        final longitude = _asDouble(item['longitude']);
        if (latitude == null ||
            longitude == null ||
            latitude < -90 ||
            latitude > 90 ||
            longitude < -180 ||
            longitude > 180) {
          continue;
        }
        points.add(GeoPoint(latitude: latitude, longitude: longitude));
      }
    }

    if (points.isEmpty) return null;
    final completedAt =
        DateTime.tryParse(metadata['completedAt']?.toString() ?? '');
    return RouteRecordingSession(
      id: id,
      startedAt: startedAt.toUtc(),
      points: List.unmodifiable(points),
      distanceMeters: _asDouble(metadata['distanceMeters']) ?? 0,
      completedAt: completedAt?.toUtc(),
    );
  }

  Map<dynamic, dynamic>? get _metadata {
    final value = _box.get(_metadataKey);
    return value is Map ? value : null;
  }

  String _segmentKey(int index) => '$_segmentPrefix$index';

  String _routeSegmentKey(String routeId, int index) =>
      '$_routeSegmentPrefix${routeId}__$index';

  double? _asDouble(Object? value) {
    if (value is num) return value.toDouble();
    return double.tryParse(value?.toString() ?? '');
  }
}
