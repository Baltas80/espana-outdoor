﻿$ErrorActionPreference = 'Stop'
$repoRoot = (Get-Location).Path
$patchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Test-Path (Join-Path $repoRoot 'pubspec.yaml'))) {
  throw "Ejecuta este script desde la raíz del repositorio España Outdoor."
}
$targets = @(
  'lib/core/storage/route_recording_store.dart',
  'lib/core/location/route_recorder.dart',
  'lib/core/navigation/backtrack.dart',
  'test/core/route_recording_store_test.dart',
  'lib/features/navigation/backtrack_page.dart'
)
foreach ($target in $targets) {
  if (-not (Test-Path (Join-Path $repoRoot $target))) {
    throw "No existe $target. No se ha modificado ningún archivo."
  }
}
foreach ($target in $targets | Select-Object -First 4) {
  if (-not (Test-Path (Join-Path $patchRoot $target))) {
    throw "Falta el archivo de parche $target. No se ha modificado ningún archivo."
  }
}

$pagePath = Join-Path $repoRoot 'lib/features/navigation/backtrack_page.dart'
$pageText = Get-Content -LiteralPath $pagePath -Raw
if ($pageText.Contains('backtrackGuidanceProvider')) {
  throw "La integración asíncrona ya parece estar aplicada. No se ha modificado ningún archivo."
}
# Locate the guidance declaration by boundaries instead of matching formatting/line endings.
$guidanceStart = $pageText.IndexOf('final guidance =')
if ($guidanceStart -lt 0) {
  throw "No se encuentra 'final guidance =' en backtrack_page.dart. No se ha modificado ningún archivo."
}
$returnIndex = $pageText.IndexOf('return Scaffold', $guidanceStart)
if ($returnIndex -lt 0) {
  throw "No se encuentra 'return Scaffold' después de guidance. No se ha modificado ningún archivo."
}
$guidanceBlock = $pageText.Substring($guidanceStart, $returnIndex - $guidanceStart)
if (-not ($guidanceBlock.Contains('BacktrackService') -and $guidanceBlock.Contains('recording.points'))) {
  throw "El bloque guidance no coincide con el esperado. No se ha modificado ningún archivo."
}
$semicolonIndex = $pageText.LastIndexOf(';', $returnIndex)
if ($semicolonIndex -lt $guidanceStart) {
  throw "No se encuentra el final de la declaración guidance. No se ha modificado ningún archivo."
}

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
foreach ($target in $targets) {
  $source = Join-Path $repoRoot $target
  Copy-Item -LiteralPath $source -Destination "$source.before-backtrack-$stamp.bak"
}
foreach ($target in $targets | Select-Object -First 4) {
  Copy-Item -LiteralPath (Join-Path $patchRoot $target) -Destination (Join-Path $repoRoot $target) -Force
}

# Add the geolocator import if Position is not already imported explicitly.
if (-not $pageText.Contains("package:geolocator/geolocator.dart")) {
  $lastImport = [regex]::Matches($pageText, '(?m)^import .+?;').Count
  if ($lastImport -eq 0) { throw "No se detectan imports en backtrack_page.dart. No se ha modificado la página." }
  $importLine = "import 'package:geolocator/geolocator.dart';`r`n"
  $firstClass = $pageText.IndexOf('class BacktrackPage extends ConsumerWidget {')
  if ($firstClass -lt 0) { throw "No se encuentra BacktrackPage. No se ha modificado la página." }
  $pageText = $pageText.Insert($firstClass, $importLine + "`r`n")
}
$provider = @'
final backtrackGuidanceProvider =
    FutureProvider.family<BacktrackGuidance?, Position>((ref, current) async {
  final recorder = ref.read(routeRecorderProvider.notifier);
  return const BacktrackService().calculateFromStream(
    current: current,
    recordedPoints: recorder.pointsForBacktrack(),
  );
});

'@
$classMarker = 'class BacktrackPage extends ConsumerWidget {'
if (-not $pageText.Contains($classMarker)) {
  throw "No se encuentra BacktrackPage. Los cuatro archivos principales se han copiado y tienen copia de seguridad; revisa los .bak antes de continuar."
}
$pageText = $pageText.Replace($classMarker, $provider + $classMarker)
$newGuidance = @'
final guidanceAsync = location.position == null
        ? null
        : ref.watch(backtrackGuidanceProvider(location.position!));
    final guidance = guidanceAsync?.valueOrNull;

'@
# Recompute indexes after adding the provider/imports, then replace through the final semicolon before Scaffold.
$guidanceStart = $pageText.IndexOf('final guidance =')
$returnIndex = $pageText.IndexOf('return Scaffold', $guidanceStart)
$semicolonIndex = $pageText.LastIndexOf(';', $returnIndex)
$pageText = $pageText.Substring(0, $guidanceStart) + $newGuidance + $pageText.Substring($semicolonIndex + 1)
Set-Content -LiteralPath $pagePath -Value $pageText -Encoding UTF8
Write-Output 'Parche aplicado a cinco archivos.'
Write-Output "Copias de seguridad creadas con sufijo .before-backtrack-$stamp.bak."
Write-Output 'No se han ejecutado pruebas ni se ha realizado commit/push.'
